class Node:
    """Represents a single entry in the Symbol Table."""
    def __init__(self, identifier, scope, type_name, line_no):
        self.identifier = identifier
        self.scope = scope
        self.type = type_name
        self.line_no = line_no
        self.next = None  
    def print_node(self):
        print(f"Identifier's Name: {self.identifier}")
        print(f"Type: {self.type}")
        print(f"Scope: {self.scope}")
        print(f"Line Number: {self.line_no}")

class SymbolTable:
    """Manages identifier metadata using a Hash Table with chaining."""
    def __init__(self, size=100):
        self.MAX = size
        self.head = [None] * self.MAX

    def _hash_f(self, identifier):
        """Generates a hash index based on the ASCII sum of the name."""
        ascii_sum = sum(ord(char) for char in identifier)
        return ascii_sum % self.MAX

    def insert(self, id_name, scope, type_name, line_no):
        """Inserts a new identifier into the table."""
        index = self._hash_f(id_name)
        new_node = Node(id_name, scope, type_name, line_no)
        
        if self.head[index] is None:
            self.head[index] = new_node
            print(f"'{id_name}' inserted successfully.")
            return True
        else:
            current = self.head[index]
            while current.next:
                current = current.next
            current.next = new_node
            print(f"'{id_name}' inserted successfully (chained).")
            return True

    def find(self, id_name):
        """Searches for an identifier and returns its scope."""
        index = self._hash_f(id_name)
        current = self.head[index]
        while current:
            if current.identifier == id_name:
                current.print_node()
                return current.scope
            current = current.next
        return "-1"

    def modify(self, id_name, scope, type_name, line_no):
        """Updates an existing identifier's information."""
        index = self._hash_f(id_name)
        current = self.head[index]
        while current:
            if current.identifier == id_name:
                current.scope = scope
                current.type = type_name
                current.line_no = line_no
                return True
            current = current.next
        return False

if __name__ == "__main__":
    st = SymbolTable()
    print("**** SYMBOL_TABLE ****")
    
    st.insert("if", "local", "keyword", 4)
    
    st.insert("number", "global", "variable", 2)
    
    if st.find("if") != "-1":
        print("Identifier is present.")
    
    if st.modify("number", "global", "variable", 3):
        print("Number identifier updated.")
        st.find("number")